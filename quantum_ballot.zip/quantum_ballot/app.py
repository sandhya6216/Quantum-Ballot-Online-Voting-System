from flask import Flask, render_template, Response, request, redirect, url_for, session
import cv2
import json
import os

app = Flask(__name__)
app.secret_key = "secret123"

DATA_FILE = "voters.json"

# -------- JSON FUNCTIONS -------- #
def load_voters():
    if not os.path.exists(DATA_FILE):
        return {}
    with open(DATA_FILE, "r") as f:
        return json.load(f)

def save_voters(data):
    with open(DATA_FILE, "w") as f:
        json.dump(data, f, indent=4)

# -------- FACE DETECTION -------- #
face_cascade = cv2.CascadeClassifier(
    cv2.data.haarcascades + "haarcascade_frontalface_default.xml"
)

face_detected = False

def generate_frames():
    global face_detected
    camera = cv2.VideoCapture(0)

    while True:
        success, frame = camera.read()
        if not success:
            break

        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        faces = face_cascade.detectMultiScale(gray, 1.3, 5)

        face_detected = len(faces) > 0

        for (x, y, w, h) in faces:
            cv2.rectangle(frame, (x, y), (x+w, y+h), (0,255,0), 2)

        ret, buffer = cv2.imencode('.jpg', frame)
        frame = buffer.tobytes()

        yield (b'--frame\r\n'
               b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')

# -------- ROUTES -------- #

@app.route('/')
def login():
    return render_template("login.html")

@app.route('/authenticate', methods=['POST'])
def authenticate():
    voter_id = request.form['voter_id']
    name = request.form['name']
    aadhaar = request.form['aadhaar']
    city = request.form['city']
    village = request.form['village']
    pincode = request.form['pincode']
    ward_no = request.form['ward_no']

    voters = load_voters()

    if voter_id in voters and voters[voter_id]["voted"]:
        return "You have already voted!"

    voters[voter_id] = {
        "name": name,
        "aadhaar": aadhaar,
        "city": city,
        "village": village,
        "pincode": pincode,
        "ward_no": ward_no,
        "voted": False
    }

    save_voters(voters)

    session['voter_id'] = voter_id
    session['name'] = name

    return render_template("auth.html", name=name)

@app.route('/video')
def video():
    return Response(generate_frames(),
                    mimetype='multipart/x-mixed-replace; boundary=frame')

@app.route('/vote')
def vote():
    global face_detected

    if 'voter_id' not in session:
        return redirect(url_for('login'))

    if face_detected:
        return render_template("vote.html", name=session['name'])
    else:
        return "Face not detected. Please go back and try again."

@app.route('/submit_vote', methods=['POST'])
def submit_vote():
    voter_id = session['voter_id']
    candidate = request.form['candidate']

    voters = load_voters()

    if voters[voter_id]["voted"]:
        return "You already voted!"

    voters[voter_id]["voted"] = True
    voters[voter_id]["party"] = candidate

    save_voters(voters)
    session.clear()

    return f"Vote submitted successfully for {candidate}!"

if __name__ == "__main__":
    app.run(debug=True)